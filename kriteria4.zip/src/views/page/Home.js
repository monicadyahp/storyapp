import HomePresenter from '../../presenter/HomePresenter'; // Correct import path
import HomeView from '../HomeView'; // Correct import path

const Home = () => {
    const token = localStorage.getItem('token');
    if (!token) {
        window.location.hash = '#/';
        return;
    }

    const homeView = new HomeView();
    const homeContainer = homeView.render();

    // Initialize presenter
    new HomePresenter(homeView);

    // When the user clicks the header (title), show Skip to Content link when Tab is pressed
    const header = homeContainer.querySelector('h2');
    header.addEventListener('click', () => {
        homeView.showSkipToContent();
    });

    // Listen for Tab press to show Skip to Content
    homeContainer.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
            homeView.showSkipToContent();
        }
    });

    // Skip to content behavior: hide on click or Enter press
    homeView.skipToContent.addEventListener('click', () => {
        homeView.hideSkipToContent();
        homeView.focusOnStories(); // Focus the stories container
    });

    homeView.skipToContent.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            homeView.hideSkipToContent();
            homeView.focusOnStories();
        }
    });

    return homeContainer;
};

export default Home;
