// src > presenter > HomePresenter.js
import { getStories } from '../api.js';
import { updateSubscriptionButton, unsubscribePushNotification, getPushSubscription } from '../utils/notificationHelper.js';

export default class HomePresenter {
    constructor(view) {
        this.view = view;
        this.init();
    }

    async init() {
        this.view.bindLogout(this.handleLogout.bind(this));
        
        // Memastikan tombol notifikasi diinisialisasi segera
        await updateSubscriptionButton('notificationButton', 'Aktifkan Notifikasi', 'Nonaktifkan Notifikasi');

        this.view.bindNotificationButton(async () => {
            const isSubscribed = await getPushSubscription();
            if (isSubscribed) {
                await unsubscribePushNotification();
            } else {
                await subscribePushNotification();
            }
        });

        // Panggil loadStories di akhir init() untuk memastikan view sudah dirender
        await this.loadStories(); 
    }

    async loadStories() {
        try {
            const stories = await getStories(); // Panggil API
            this.view.showStories(stories); // Tampilkan hasil dari API atau cache
        } catch (error) {
            console.error('Error fetching stories:', error);
            // Ini akan menangani jika API gagal (misal offline dan tidak ada di cache)
            // showStories dengan array kosong akan menampilkan pesan "Tidak ada cerita tersedia."
            this.view.showStories([]); 
        }
    }

    handleLogout() {
        localStorage.removeItem('token');
        unsubscribePushNotification();
        window.location.hash = '#/';
        window.location.reload();
    }
}