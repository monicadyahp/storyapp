// src > routes.js
import Landing from './views/landing.js'; // Ini fungsi
import Login from './views/login.js';     // Ini fungsi
import Register from './views/register.js'; // Ini fungsi

// Impor semua kelas View secara eksplisit dengan nama kelasnya
import HomeView from './views/page/Home.js';    // <-- PASTIKAN NAMA INI SAMA DENGAN CLASS DI HOME.JS
import DetailView from './views/DetailView.js'; // Pastikan DetailView.js ada di src/views/DetailView.js
import BookmarkView from './views/page/Bookmark.js'; // Pastikan Bookmark.js ada di src/views/page/Bookmark.js
import AddView from './views/page/Add.js';      // <-- PASTIKAN NAMA INI SAMA DENGAN CLASS DI ADD.JS

// Impor semua kelas Presenter
import HomePresenter from './presenter/HomePresenter.js';
import DetailPresenter from './presenter/DetailPresenter.js';
import BookmarkPresenter from './presenter/BookmarkPresenter.js';
import AddPresenter from './presenter/AddPresenter.js'; // Jika Add punya presenter


// Objek routes hanya untuk pemetaan awal, bukan untuk instansiasi
// Instansiasi akan dilakukan di dalam router()
const routes = {
    '': Landing, // Fungsi
    '#/': HomeView, // Kelas (akan diinstansi di router)
    '#/login': Login, // Fungsi
    '#/register': Register, // Fungsi
    '#/add': AddView, // Kelas (akan diinstansi di router)
    '#/detail': DetailView, // Kelas (akan diinstansi di router)
    '#/bookmark': BookmarkView // Kelas (akan diinstansi di router)
};

const router = async () => {
    try {
        const token = localStorage.getItem('token');
        const hash = location.hash.split('?')[0];
        const urlParams = new URLSearchParams(location.hash.split('?')[1]);
        const storyId = urlParams.get('id');

        let CurrentViewClassOrFunction; // Akan menyimpan kelas View atau fungsi View
        let viewInstance; // Akan menyimpan instance HTMLElement yang sudah dirender
        let presenterInstance = null; // Akan menyimpan instance Presenter

        if (token) {
            // Pengguna sudah login
            if (hash === '' || hash === '#/') {
                CurrentViewClassOrFunction = HomeView;
            } else if (hash.startsWith('#/detail')) {
                if (storyId) {
                    CurrentViewClassOrFunction = DetailView;
                } else {
                    CurrentViewClassOrFunction = HomeView; // Fallback jika tidak ada storyId
                }
            } else if (hash === '#/bookmark') {
                CurrentViewClassOrFunction = BookmarkView;
            } else if (hash === '#/add') {
                CurrentViewClassOrFunction = AddView;
            }
            else {
                CurrentViewClassOrFunction = routes[hash]; // Untuk rute lain yang terdaftar
                if (!CurrentViewClassOrFunction) { // Jika rute tidak ditemukan setelah login
                    CurrentViewClassOrFunction = HomeView; // Default ke Home
                }
            }
        } else {
            // Pengguna belum login
            CurrentViewClassOrFunction = routes[hash];
            if (!CurrentViewClassOrFunction) { // Jika rute tidak ditemukan saat belum login
                CurrentViewClassOrFunction = Landing; // Default ke Landing
            }
        }

        // --- Sekarang kita instansiasi View dan Presenter sesuai tipe ---
        if (typeof CurrentViewClassOrFunction === 'function' && CurrentViewClassOrFunction.prototype && CurrentViewClassOrFunction.prototype.render) {
            // Ini adalah KELAS View (HomeView, DetailView, BookmarkView, AddView)
            viewInstance = new CurrentViewClassOrFunction();

            // Tentukan Presenter yang sesuai
            if (CurrentViewClassOrFunction === HomeView) {
                presenterInstance = new HomePresenter(viewInstance);
            } else if (CurrentViewClassOrFunction === DetailView) {
                // DetailPresenter butuh view di constructor, dan id dari URL
                presenterInstance = new DetailPresenter(viewInstance);
                // DetailPresenter.initialize() akan dipanggil setelah view di-append
            } else if (CurrentViewClassOrFunction === BookmarkView) {
                presenterInstance = new BookmarkPresenter(viewInstance);
                // BookmarkPresenter.init() akan dipanggil setelah view di-append
            } else if (CurrentViewClassOrFunction === AddView) {
                presenterInstance = new AddPresenter(viewInstance);
                // AddPresenter.init() atau initialize() akan dipanggil setelah view di-append
            }
            // Render elemen DOM dari instance View
            viewInstance = viewInstance.render(); // Dapatkan HTMLElement
        } else if (typeof CurrentViewClassOrFunction === 'function') {
            // Ini adalah FUNGSI View (Landing, Login, Register)
            viewInstance = CurrentViewClassOrFunction(); // Panggil fungsi untuk mendapatkan HTMLElement
            presenterInstance = null; // Fungsi View ini tidak punya Presenter terpisah
        } else {
            // Kasus tidak terduga, mungkin null atau undefined
            document.getElementById('app').innerHTML = '<h1>Page Not Found - Invalid Route Component</h1>';
            return;
        }

        if (!viewInstance) {
            document.getElementById('app').innerHTML = '<h1>Page Not Found - View Instance Empty</h1>';
            return;
        }

        const appContainer = document.getElementById('app');
        while (appContainer.firstChild) {
            appContainer.removeChild(appContainer.firstChild);
        }

        appContainer.appendChild(viewInstance); // Append HTMLElement ke DOM

        // Panggil inisialisasi presenter SETELAH elemen di-append
        if (presenterInstance) {
            if (presenterInstance.initialize && typeof presenterInstance.initialize === 'function') {
                await presenterInstance.initialize(); // Untuk DetailPresenter
            } else if (presenterInstance.init && typeof presenterInstance.init === 'function') {
                await presenterInstance.init(); // Untuk HomePresenter, BookmarkPresenter
            } else {
                // Presenter mungkin tidak memiliki metode init/initialize asinkron,
                // atau init/initialize sudah dipanggil di constructor.
                console.warn('Presenter does not have an explicit async init/initialize method to call after view append.');
            }
        }
        
    } catch (error) {
        console.error("Routing Error:", error);
        document.getElementById('app').innerHTML = `<h1>Error loading page: ${error.message || error}</h1>`;
    }
};

export { router };